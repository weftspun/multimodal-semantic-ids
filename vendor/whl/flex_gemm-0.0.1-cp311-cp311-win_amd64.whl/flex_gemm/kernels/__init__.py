try:
    from . import triton
except ImportError:
    pass
from . import cuda